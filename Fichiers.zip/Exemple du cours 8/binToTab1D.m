function [ tab ] = binToTab1D( filename )
%BINTOTAB1D Retourne un tab 1D contenu dans un fichier
%   IN:
%       filename - Le nom du fichier a ouvrir 
%   OUT:
%       tab - Le tableau lut dans le fichier

fid = fopen(filename);

nb = fread(fid,1,'int32');

tab = fread(fid,nb,'double');

fclose(fid);


end

