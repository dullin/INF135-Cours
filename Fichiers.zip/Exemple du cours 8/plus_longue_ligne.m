function [ nbChar ] = plus_longue_ligne( nom_fichier )
%PLUS_LONGUE_LIGNE Retourne le nombre de caracteres de la plus longue ligne
%du fichier
%   IN:
%       nom_fichier - Le nom du fichier a acceder
%   OUT:
%       nb_char - Le nombre de caracteres de la plus longue ligne du
%       fichier

%Ouverture du fichier
fid = fopen(nom_fichier);

%Validation avec assert
assert(fid ~= -1);

tabNbChar = [];

while(~feof(fid))
    ligne_courante = fgetl(fid);
    tabNbChar = [tabNbChar numel(ligne_courante)];
end

nbChar = max(tabNbChar);

fclose(fid);

end

