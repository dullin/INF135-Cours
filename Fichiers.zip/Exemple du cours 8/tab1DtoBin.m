function  tab1DtoBin( tab, filename )
%TAB1DTOBIN Ecrit un tab 1D dans un fichier
%   IN:
%       tab - Le tableau a ecrire
%       filename - Le nom du fichier a ecrire

fid = fopen(filename,'w');

assert(fid~=-1);

fwrite(fid,numel(tab),'int32');

fwrite(fid,tab,'double');

fclose(fid);

end

