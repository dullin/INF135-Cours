fclose('all');

fid = fopen('donnees_formates1.txt');
tab1 = fscanf(fid,'%g;');
fclose(fid);

fid = fopen('donnees_formates2.txt');
tab2 = fscanf(fid,'%g');
fclose(fid);
%%
fid = fopen('donnees_formates3.txt');
tab3 = fscanf(fid,'%g_%g;')
fclose(fid);
%%
fid = fopen('donnees_formates4.txt');

tab4(1) = fscanf(fid,'first: %i ');
tab4(2) = fscanf(fid,'second: %i\n');
tab4(3) = fscanf(fid,'third: %i');

frewind(fid)
tab4_2= fscanf(fid,'first: %i second: %i\nthird: %i');
fclose(fid);